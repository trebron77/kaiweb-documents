# Archives

Versions antérieures, brouillons et pièces remplacées. **Rien n'est supprimé ici** : on archive.

| Élément | Nature |
|---|---|
| `CGU-CGV & annexes/` | Générations v1.1 / v1.2 des CGU-CGV, DPA, cookies, mentions légales, SLA, politique de confidentialité (PDF) |
| `CGU-CGV & annexes/Fichier - Exporter en PDF/` | Copies `.docx` des documents au moment de l'export PDF (11 et 16/10) |
| `Contrat de revente SaaS.pdf` | Première version PDF du contrat revendeurs (09/10) |
| `Draft CGU-CGV-Politique de Confidentialité…pdf` | Brouillon initial (08/10) |
| `Statuts SASU.pdf`, `Statut SASU'.pdf` | Premières versions des statuts (08/10) |
| `Creation_Dossiers.bat` | Script de création de l'arborescence (obsolète, conservé pour mémoire) |
| `deepseek_text_20261011_544a95.txt` | Note de travail |

⚠️ `Satut SASU.docx` = faute de frappe pour « Statut SASU », version archivée du 16/10.

**Règle** : quand un document est remplacé, déplacer l'ancienne version ici plutôt que la supprimer,
et noter la date dans le nom si plusieurs générations coexistent.
